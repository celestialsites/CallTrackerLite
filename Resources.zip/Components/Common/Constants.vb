﻿
Namespace Components.Common
    Public Class Constants
#Region "Misc."

        Public Const DESKTOPMODULE_NAME As String = "CTLiteAdmin"
        Public Const DESKTOPMODULE_FRIENDLYNAME As String = "Call Tracker Lite"

#End Region

    End Class

End Namespace


