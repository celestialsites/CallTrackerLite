﻿var $dnnuclear = $dnnuclear || {};

$dnnuclear.mainController = function mainController($http, $log, AppServiceFramework) {
    // Set vm to the scope of this controller
    var vm = this;

    // Set API base url
    var serviceRoot = AppServiceFramework.getServiceRoot('CTLiteAdmin');

    vm.EditMode = true;
    vm.dispatchers = [];
    vm.regions = [];
    vm.EditIndex = -1;
    //vm.Userlist = $dnnuclear.UserList;

    //vm.show = 'default';

    //Get Dispatchers

    vm.getAllDispatchers = function () {
        $http.get(serviceRoot + 'home/dpList')
            .success(function (response) {
                vm.dispatchers = response;
            })
            .error(function (data) {
                $log.error('Failure to return dispatcher', data);
            });
    }

    vm.createUpdateDispatcher = function (dispatcher) {
        // make a copy of the dispatcher to not change directive scope
        var dispatcherCp = angular.copy(dispatcher);
        var sMethod = "home/dpnew";
        if (dispatcherCp.DispatcherId > 0) { sMethod = "home/dpupdate"; }

        $http.post(serviceRoot + sMethod, dispatcherCp)
            .success(function (response) {
                if (sMethod === "home/dpnew") {
                    var id = parseInt(response);
                    if (id > 0) {
                        dispatcherCp.DispatcherId = id;
                        vm.dispatchers.push(dispatcherCp);
                   }
                } else {
                    if (vm.EditIndex >= 0)
                        vm.dispatchers[vm.EditIndex] = dispatcherCp;

                }
            })
            .error(function (errorPayload) {
                $log.error('failure saving dispatcher', errorPayload);
            });
    }

    vm.deleteDispatcher = function (dispatcher, idx) {
        if (confirm('Are you sure to delete "' + dispatcher.DispatcherName + '"?')) {
            $http.post(serviceRoot + 'home/dpdelete', angular.toJson(dispatcher))
                .success(function (response) {
                    vm.dispatchers.splice(idx, 1);
                })
                .error(function (errorPayload) {
                    $log.error('failure deleting dispatcher', errorPayload);
                });
        }
    }


    vm.getAllDPCodes = function () {
        $http.get(serviceRoot + 'home/dpcodeList')
            .success(function (response) {
                vm.dpcodes = response;
            })
            .error(function (data) {
                $log.error('Failure to return Dispatch code', data);
            });
    }

    vm.createUpdateDPCode = function (dpcode) {
        // make a copy of the dispatcher to not change directive scope
        var dpcodeCp = angular.copy(dpcode);
        var sMethod = "home/dpcodenew";
        if (dpcodeCp.DispatchCodeId > 0) { sMethod = "home/dpcodeupdate"; }

        $http.post(serviceRoot + sMethod, dpcodeCp)
            .success(function (response) {
                if (sMethod === "home/dpcodenew") {
                    var id = parseInt(response);
                    if (id > 0) {
                        dpcodeCp.DispatchCodeId = id;
                        vm.dpcodes.push(dpcodeCp);
                    }
                } else {
                    if (vm.EditIndex >= 0)
                        vm.dpcodes[vm.EditIndex] = dpcodeCp;

                }
            })
            .error(function (errorPayload) {
                $log.error('failure saving dispatch code', errorPayload);
            });
    }

    vm.deleteDPCode = function (dpcode, idx) {
        if (confirm('Are you sure to delete "' + dpcode.DispatchCodeName + '"?')) {
            $http.post(serviceRoot + 'home/dpcodedelete', angular.toJson(dpcode))
                .success(function (response) {
                    vm.dpcodes.splice(idx, 1);
                })
                .error(function (errorPayload) {
                    $log.error('failure deleting dispatch code', errorPayload);
                });
        }
    }



    vm.getAllCitys = function () {
        $http.get(serviceRoot + 'home/cityList')
            .success(function (response) {
                vm.citys = response;
            })
            .error(function (data) {
                $log.error('Failure to return dispatcher', data);
            });
    }


    vm.createUpdateCity = function (city) {
        // make a copy of the dispatcher to not change directive scope
        var cityCp = angular.copy(city);
        var sMethod = "home/citynew";
        if (cityCp.CityId > 0) { sMethod = "home/cityupdate"; }

        $http.post(serviceRoot + sMethod, cityCp)
            .success(function (response) {
                if (sMethod === "home/citynew") {
                    var id = parseInt(response);
                    if (id > 0) {
                        cityCp.CityId = id;
                        vm.citys.push(cityCp);
                    }
                } else {
                    if (vm.EditIndex >= 0)
                        vm.citys[vm.EditIndex] = cityCp;

                }
            })
            .error(function (errorPayload) {
                $log.error('failure saving City', errorPayload);
            });
    }

    vm.deleteCity = function (city, idx) {
        if (confirm('Are you sure to delete "' + city.CityName + '"?')) {
            $http.post(serviceRoot + 'home/citydelete', angular.toJson(city))
                .success(function (response) {
                    vm.citys.splice(idx, 1);
                })
                .error(function (errorPayload) {
                    $log.error('failure deleting city code', errorPayload);
                });
        }
    }



    vm.addCalls = function () {
        vm.show = 'new';
        $http.get(serviceRoot + 'home/GetRegions')
           .success(function (response) {
               vm.regions = response;
           })
           .error(function (data) {
               console.log(data);
           });

    }

    vm.adminDispatchers = function () {
        vm.show = 'dispatch';
        vm.getAllDispatchers();
    }

    vm.adminDPCodes = function () {
        vm.show = 'dpcode';
        vm.getAllDPCodes();
    }

    vm.adminCitys = function () {
        vm.show = 'city';
        vm.getAllCitys();
    }

    vm.cancel = function () {
        vm.show = 'default';
    }

    vm.init = function (editable) {
        vm.EditMode = editable;
        vm.show = 'default';
    }

}