﻿var $dnnuclear = $dnnuclear || {};

$dnnuclear.appAddEditDirective = function (ModulePath) {

    return {
        scope: {
            editEntity: '=?',
            template: '@',
            mdlname: '@',
            mdlid: '=',
            title: '@',
            saveIt: '&saveFunction',
            refreshIt: '&'
        },
        restrict: 'E',
        //templateUrl: ModulePath + 'Resources/js/templates/dispatcher-addedit.html',
        templateUrl: ModulePath + 'Resources/js/templates/' + scope.template + '-addedit.html',
        controller: ['$scope', function ($scope) {
            switch (scope.template) {
                case 'dispatcher':
                    if (typeof $scope.editEntity === 'undefined') {
                        $scope.editEntity = new $dnnuclear.Dispatcher();
                    }
                    $scope.showAddEdit = function () {
                        $(".modal").hide();
                        $("#mdlAddEditDispatcher-" + $scope.editEntity.DispatcherId).modal();
                    };
                    break;
                case 'region':
                    if (typeof $scope.editEntity === 'undefined') {
                        $scope.editEntity = new $dnnuclear.city();
                    }
                    $scope.showAddEdit = function () {
                        $(".modal").hide();
                        $("#mdlAddEditCity-" + $scope.editEntity.CityId).modal();
                    };
                    break;
                default:
                    if (typeof $scope.editEntity === 'undefined') {
                        $scope.editEntity = new $dnnuclear.DPCode();
                    }
                    $scope.showAddEdit = function () {
                        $(".modal").hide();
                        $("#mdlAddEditDpcode-" + $scope.editEntity.DispatchCodeId).modal();
                    };
            }

        }],
        link: function (scope, elem, attrs) {
            scope.Name = attrs['name'];

            scope.saveButton = function (e, form) {
                e.preventDefault();
                scope.invalidSubmitAttempt = false;
                if (form.$invalid) {
                    scope.invalidSubmitAttempt = true;
                    return;
                }

                // Call our passed in save function
                if (angular.isFunction(scope.saveIt)) {
                    var saveFnExp = scope.saveIt();
                    saveFnExp(scope.editEntity);
                }

                // Hide the modal, reset the scope, reset the form validation
                //$("#mdlAddEditDispatcher-" + scope.editEntity.DispatcherId).modal('hide');
                //if (scope.editEntity.DispatcherId === 0)
                //    scope.editEntity = new $dnnuclear.Dispatcher();
                $("#mdlAddEdit" + scope.mdlname + "-" + scope.mdlid).modal('hide');
               switch (scope.template) {
                    case 'dispatcher':
                        if (typeof scope.editEntity.DispatcherId === 0) {
                            scope.editEntity = new $dnnuclear.Dispatcher();
                        };
                        break;
                    case 'region':
                        if (typeof scope.editEntity.CityId === 0) {
                            scope.editEntity = new $dnnuclear.city();
                        };
                        break;
                    default:
                        if (typeof scope.editEntity.DispatchCodeId === 0) {
                            scope.editEntity = new $dnnuclear.DPCode();
                        };

                }
                form.$setPristine();
            }

            scope.cancelButton = function () {
                $("#mdlAddEdit" + scope.mdlname + "-" + scope.mdlid).modal('hide');
                $("#mdlAddEdit" + scope.mdlname + "-" + scope.mdlid).on('hidden.bs.modal', function () {
                    if (angular.isFunction(scope.refreshIt)) {
                        var refFnExp = scope.refreshIt();
                        refFnExp();
                    }
                })
                //$("#mdlAddEditDispatcher-" + scope.editEntity.DispatcherId).modal('hide');
                //$("#mdlAddEditDispatcher-" + scope.editEntity.DispatcherId).on('hidden.bs.modal', function () {
                //    if (angular.isFunction(scope.refreshIt)) {
                //        var refFnExp = scope.refreshIt();
                //        refFnExp();
                //    }
                //})
            }
        }
    }
};

$dnnuclear.Dispatcher = function () {
    this.DispatcherId = 0;
    this.DispatcherName = '';
    this.DispatcherType = '';
    this.CellPhone = '';
    this.HomePhone = '';
    this.AltPhone = '';
};

$dnnuclear.city = function () {
    this.CityId = 0;
    this.CityName = '';
    this.RegionName = '';
    this.UtilityType = '';
};

$dnnuclear.DPCode = function () {
    this.DispatchCodeId = 0;
    this.DispatchCodeName = '';
};

