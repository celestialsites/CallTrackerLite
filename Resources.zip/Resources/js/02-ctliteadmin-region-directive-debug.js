﻿var $dnnuclear = $dnnuclear || {};

$dnnuclear.regionAddEditDirective = function (ModulePath) {
    return {
        scope: {
            editEntity: '=?',
            title: '@',
            saveFunction: '&saveFunction',
            refreshRegions: '&'
        },
        restrict: 'E',
        templateUrl: ModulePath + 'Resources/js/templates/region-addedit.html',
        controller: ['$scope', function ($scope) {
            if (typeof $scope.editEntity === 'undefined') {
                $scope.editEntity = new $dnnuclear.city();

            }
            $scope.showAddEdit = function () {
                $(".modal").hide();
                $("#mdlAddEditCity-" + $scope.editEntity.CityId).modal();
            };
        }],
        link: function (scope, elem, attrs) {
            scope.Name = attrs['name'];

            scope.saveButton = function (e, form) {
                e.preventDefault();
                scope.invalidSubmitAttempt = false;
                if (form.$invalid) {
                    scope.invalidSubmitAttempt = true;
                    return;
                }

                // Call our passed in save DPCode function
                if (angular.isFunction(scope.saveFunction)) {
                    var saveFnExp = scope.saveFunction();
                    saveFnExp(scope.editEntity);
                }

                // Hide the modal, reset the scope, reset the form validation
                $("#mdlAddEditCity-" + scope.editEntity.CityId).modal('hide');
                if (scope.editEntity.CityId === 0)
                    scope.editEntity = new $dnnuclear.city();
                form.$setPristine();
            }

            scope.cancelButton = function () {
                $("#mdlAddEditCity-" + scope.editEntity.CityId).modal('hide');
                $("#mdlAddEditCity-" + scope.editEntity.CityId).on('hidden.bs.modal', function () {
                    if (angular.isFunction(scope.refreshCitys)) {
                        var refFnExp = scope.refreshCitys();
                        refFnExp();
                    }
                })
            }
        }
    }
};
 
$dnnuclear.city = function () {
    this.CityId = 0;
    this.CityName = '';
    this.RegionName = '';
    this.UtilityType = '';
};