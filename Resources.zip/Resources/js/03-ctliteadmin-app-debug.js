﻿(function () {
    angular.module("myCTLAdminApp", ['dnnuclearDnn'])

    //Directives
     .directive("addEditDispatcher", $dnnuclear.AddEditDirective)
     .directive("addEditDpcode", $dnnuclear.dpcodeAddEditDirective)
     .directive("addEditRegion", $dnnuclear.regionAddEditDirective)
     //.directive("addEditEntity", $dnnuclear.appAddEditDirective)

    //Controllers
    .controller("mainController", ['$http', '$log', 'AppServiceFramework', $dnnuclear.mainController])
}());

